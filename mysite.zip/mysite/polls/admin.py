from django.contrib import admin #somesht - TS!@#123
from . models import books

# Register your models here.
admin.site.register(books)